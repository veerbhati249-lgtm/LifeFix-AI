/**
 * server/server.js
 * ------------------
 * This is the single entry point of the backend application.
 *
 * Responsibilities:
 *  1. Load environment variables from .env (so the API key stays out of source code).
 *  2. Configure Express middleware (JSON body parsing, CORS).
 *  3. Serve the static frontend (everything in /public).
 *  4. Mount the API routes (everything under /api/*).
 *  5. Start listening on the configured port.
 *
 * The frontend NEVER talks to the AI provider directly - it only ever calls
 * this server's /api/chat endpoint. The AI API key lives only here, in
 * process.env, and is never sent to the browser.
 */

require('dotenv').config(); // Reads .env and populates process.env

const path = require('path');
const express = require('express');
const cors = require('cors');

const chatRoutes = require('../routes/chatRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Fail fast if the API key is missing, with a helpful message ---
if (!process.env.ANTHROPIC_API_KEY) {
  console.warn(
    '\n⚠️  WARNING: ANTHROPIC_API_KEY is not set.\n' +
      '   Copy .env.example to .env and add your real API key before chatting.\n'
  );
}

// --- Middleware ---
app.use(cors()); // Allows the frontend (same or different origin) to call this API
app.use(express.json({ limit: '1mb' })); // Parses incoming JSON request bodies

// --- Static frontend ---
// Anything in /public (index.html, client JS, images) is served as-is.
app.use(express.static(path.join(__dirname, '..', 'public')));
// The /styles folder holds our stylesheet(s) and is exposed at /styles/*
app.use('/styles', express.static(path.join(__dirname, '..', 'styles')));
// The /client folder holds the frontend's application source (app.js) served at /client/*
app.use('/client', express.static(path.join(__dirname, '..', 'client')));

// --- API routes ---
// All chat-related endpoints live under /api/chat
app.use('/api/chat', chatRoutes);

// --- Simple health check, useful for uptime monitors ---
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// --- Fallback 404 for unknown API routes ---
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'API route not found.' });
});

app.listen(PORT, () => {
  console.log(`🚀 AI Chat App running at http://localhost:${PORT}`);
});

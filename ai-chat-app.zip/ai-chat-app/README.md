# Signal — AI Chat App

A full-stack AI chat application:

- **Frontend**: vanilla HTML/CSS/JS, responsive, with a loading animation, error
  handling, and locally-persisted chat history/sessions.
- **Backend**: Node.js + Express. It is the *only* thing that talks to the AI
  provider (Anthropic's Claude API). Your API key lives in a `.env` file on the
  server and is never sent to, or visible from, the browser.

## Project structure

```
ai-chat-app/
├── client/               # Frontend application source (served at /client/*)
│   └── app.js            # Chat UI logic: rendering, fetch calls, history, errors
├── controllers/          # Backend request handlers
│   └── chatController.js # Calls the Anthropic API using the server-side key
├── public/               # Static files served at the site root ("/")
│   ├── index.html        # The chat page markup
│   └── assets/
│       └── favicon.svg
├── routes/               # Express route definitions
│   └── chatRoutes.js     # POST /api/chat
├── server/                # App entry point
│   └── server.js         # Express setup, middleware, static hosting, route mounting
├── styles/                # Stylesheets (served at /styles/*)
│   └── style.css
├── .env.example           # Template for required environment variables
├── .gitignore
├── package.json
└── README.md
```

## How the pieces fit together

1. The browser loads `public/index.html`, which pulls in `styles/style.css`
   and `client/app.js`.
2. When you send a message, `client/app.js` calls `POST /api/chat` on **our
   own backend** — it never talks to Anthropic directly.
3. `routes/chatRoutes.js` forwards that request to
   `controllers/chatController.js`.
4. `chatController.js` reads `ANTHROPIC_API_KEY` from `process.env` (loaded
   from `.env` by `dotenv` in `server/server.js`) and calls the Anthropic
   Messages API on the server side.
5. The reply is sent back to the browser as plain JSON — no key, no
   provider-specific details, ever reach the client.

## Setup

**Requirements:** Node.js 18 or later (for built-in `fetch`).

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create your environment file:

   ```bash
   cp .env.example .env
   ```

3. Open `.env` and add your real Anthropic API key:

   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
   ```

4. Start the app:

   ```bash
   npm start
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser.

For auto-restart on file changes during development, use:

```bash
npm run dev
```

## Environment variables

| Variable            | Required | Description                                   |
|----------------------|----------|------------------------------------------------|
| `ANTHROPIC_API_KEY`  | Yes      | Your secret key from the Anthropic console.     |
| `AI_MODEL`           | No       | Model name to use (default: `claude-sonnet-4-6`). |
| `PORT`               | No       | Port for the Express server (default: `3000`).  |

## Security notes

- `.env` is listed in `.gitignore` — never commit your real key.
- The API key is only ever read on the server (`chatController.js`) and is
  never included in any response sent to the browser.
- The frontend only ever calls relative paths on its own origin
  (`/api/chat`), so there's no third-party endpoint or key baked into
  client-side code.

## Notes on chat history

Chat sessions are stored in the browser's `localStorage`, keyed per-session,
so your conversation list survives a page refresh. This is client-side
convenience storage only — it is not synced across devices and isn't sent
anywhere except back to `/api/chat` as conversational context for follow-up
messages.

/**
 * controllers/chatController.js
 * -------------------------------
 * Contains the actual business logic for the chat endpoint.
 *
 * This is the ONLY place in the app that talks to the Anthropic API.
 * It reads the secret key from process.env (populated from .env by dotenv
 * in server.js) and forwards the conversation to Anthropic's Messages API.
 * The key itself is never sent to, or readable by, the browser.
 */

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2023-06-01';
const MAX_HISTORY_MESSAGES = 20; // Cap how much history we forward, to control cost/latency
const REQUEST_TIMEOUT_MS = 30000;

/**
 * POST /api/chat
 * Expects: { message: string, history?: Array<{ role: 'user'|'assistant', content: string }> }
 * Responds: { reply: string } on success, or { error: string } with a 4xx/5xx status on failure.
 */
async function sendMessage(req, res) {
  try {
    const { message, history } = req.body || {};

    // --- Basic input validation ---
    if (typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ error: 'A non-empty "message" string is required.' });
    }
    if (message.length > 8000) {
      return res.status(400).json({ error: 'Message is too long (max 8000 characters).' });
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      // Server misconfiguration - never expose this detail to random clients in production,
      // but it's helpful during local setup.
      return res.status(500).json({
        error: 'Server is missing ANTHROPIC_API_KEY. Add it to your .env file and restart.',
      });
    }

    // --- Build the message list Anthropic expects ---
    const cleanHistory = Array.isArray(history)
      ? history
          .filter(
            (m) =>
              m &&
              (m.role === 'user' || m.role === 'assistant') &&
              typeof m.content === 'string'
          )
          .slice(-MAX_HISTORY_MESSAGES)
      : [];

    const messages = [...cleanHistory, { role: 'user', content: message }];

    // --- Call the Anthropic API with a timeout guard ---
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    let response;
    try {
      response = await fetch(ANTHROPIC_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': ANTHROPIC_VERSION,
        },
        body: JSON.stringify({
          model: process.env.AI_MODEL || 'claude-sonnet-4-6',
          max_tokens: 1024,
          messages,
        }),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      console.error('Anthropic API error:', response.status, errorBody);
      return res.status(502).json({
        error: 'The AI service returned an error. Please try again in a moment.',
      });
    }

    const data = await response.json();

    // Anthropic returns content as an array of blocks; join any text blocks together.
    const reply = (data.content || [])
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('\n')
      .trim();

    if (!reply) {
      return res.status(502).json({ error: 'The AI returned an empty response.' });
    }

    return res.json({ reply });
  } catch (err) {
    if (err.name === 'AbortError') {
      console.error('Anthropic API request timed out.');
      return res.status(504).json({ error: 'The AI service took too long to respond.' });
    }
    console.error('Unexpected error in sendMessage:', err);
    return res.status(500).json({ error: 'Something went wrong on the server.' });
  }
}

module.exports = { sendMessage };

/**
 * routes/chatRoutes.js
 * ---------------------
 * Defines the HTTP routes related to chat functionality.
 * Routes stay "thin" - they just map an HTTP verb + path to a controller
 * function. All real logic (calling the AI API, error handling) lives in
 * controllers/chatController.js.
 */

const express = require('express');
const router = express.Router();
const { sendMessage } = require('../controllers/chatController');

// POST /api/chat
// Body: { message: string, history: [{ role: 'user'|'assistant', content: string }] }
// Returns: { reply: string }
router.post('/', sendMessage);

module.exports = router;

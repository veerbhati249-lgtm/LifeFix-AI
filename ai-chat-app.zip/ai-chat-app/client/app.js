/**
 * client/app.js
 * --------------
 * All frontend behavior for the chat app lives here. This file:
 *   - Renders messages to the DOM
 *   - Sends the user's message to OUR backend at POST /api/chat
 *     (never directly to any AI provider - the browser never sees an API key)
 *   - Shows a loading animation while waiting for a reply
 *   - Shows an error banner if the request fails
 *   - Persists chat sessions in localStorage so history survives a refresh
 */

(() => {
  'use strict';

  // ---------- DOM references ----------
  const messagesEl = document.getElementById('messages');
  const emptyStateEl = document.getElementById('emptyState');
  const formEl = document.getElementById('chatForm');
  const inputEl = document.getElementById('messageInput');
  const sendBtn = document.getElementById('sendBtn');
  const loadingEl = document.getElementById('loadingIndicator');
  const errorBannerEl = document.getElementById('errorBanner');
  const errorTextEl = document.getElementById('errorText');
  const dismissErrorBtn = document.getElementById('dismissError');
  const newChatBtn = document.getElementById('newChatBtn');
  const historyListEl = document.getElementById('historyList');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');

  // ---------- Storage helpers ----------
  const STORAGE_KEY = 'signal_chat_sessions';
  const CURRENT_KEY = 'signal_current_session';

  /** Load all saved sessions from localStorage (or an empty array). */
  function loadSessions() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch {
      return [];
    }
  }

  /** Persist all sessions back to localStorage. */
  function saveSessions(sessions) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  }

  function makeId() {
    return `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }

  // ---------- App state ----------
  let sessions = loadSessions();
  let currentSessionId = localStorage.getItem(CURRENT_KEY);

  function getCurrentSession() {
    return sessions.find((s) => s.id === currentSessionId) || null;
  }

  function ensureSession() {
    if (!getCurrentSession()) {
      const session = { id: makeId(), title: 'New chat', messages: [] };
      sessions.unshift(session);
      currentSessionId = session.id;
      localStorage.setItem(CURRENT_KEY, currentSessionId);
      saveSessions(sessions);
    }
    return getCurrentSession();
  }

  // ---------- Rendering ----------

  function formatTime(ts) {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function renderMessages() {
    const session = getCurrentSession();
    messagesEl.innerHTML = '';

    if (!session || session.messages.length === 0) {
      messagesEl.appendChild(emptyStateEl);
      return;
    }

    for (const msg of session.messages) {
      const bubble = document.createElement('div');
      bubble.className = `message message--${msg.role === 'user' ? 'user' : 'assistant'}`;

      const meta = document.createElement('span');
      meta.className = 'message__meta';
      meta.textContent = `${msg.role === 'user' ? 'You' : 'Signal'} · ${formatTime(msg.timestamp)}`;

      const body = document.createElement('div');
      body.textContent = msg.content;

      bubble.appendChild(meta);
      bubble.appendChild(body);
      messagesEl.appendChild(bubble);
    }

    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function renderHistoryList() {
    historyListEl.innerHTML = '';
    for (const session of sessions) {
      const li = document.createElement('li');
      li.className = `history-list__item${session.id === currentSessionId ? ' history-list__item--active' : ''}`;
      li.textContent = session.title || 'New chat';
      li.title = session.title || 'New chat';
      li.addEventListener('click', () => {
        currentSessionId = session.id;
        localStorage.setItem(CURRENT_KEY, currentSessionId);
        renderHistoryList();
        renderMessages();
      });
      historyListEl.appendChild(li);
    }
  }

  // ---------- Error + loading UI ----------

  function showError(message) {
    errorTextEl.textContent = message;
    errorBannerEl.hidden = false;
    statusDot.classList.add('status__dot--error');
    statusText.textContent = 'Error';
  }

  function clearError() {
    errorBannerEl.hidden = true;
    statusDot.classList.remove('status__dot--error');
    statusText.textContent = 'Online';
  }

  function setLoading(isLoading) {
    loadingEl.hidden = !isLoading;
    sendBtn.disabled = isLoading;
    inputEl.disabled = isLoading;
  }

  dismissErrorBtn.addEventListener('click', clearError);

  // ---------- Auto-resizing textarea ----------

  inputEl.addEventListener('input', () => {
    inputEl.style.height = 'auto';
    inputEl.style.height = `${Math.min(inputEl.scrollHeight, 160)}px`;
  });

  // Submit on Enter, newline on Shift+Enter
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      formEl.requestSubmit();
    }
  });

  // ---------- Sending a message ----------

  async function handleSubmit(e) {
    e.preventDefault();
    const text = inputEl.value.trim();
    if (!text) return;

    clearError();
    const session = ensureSession();

    // Optimistically add the user's message
    session.messages.push({ role: 'user', content: text, timestamp: Date.now() });
    if (session.title === 'New chat') {
      session.title = text.slice(0, 40) + (text.length > 40 ? '…' : '');
    }
    saveSessions(sessions);
    renderMessages();
    renderHistoryList();

    inputEl.value = '';
    inputEl.style.height = 'auto';
    setLoading(true);

    // Build the history payload the backend/AI needs for context
    const history = session.messages
      .slice(0, -1) // everything before the message we just added
      .map((m) => ({ role: m.role, content: m.content }));

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history }),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(data.error || `Request failed (${response.status})`);
      }

      session.messages.push({
        role: 'assistant',
        content: data.reply,
        timestamp: Date.now(),
      });
      saveSessions(sessions);
      renderMessages();
    } catch (err) {
      console.error(err);
      showError(err.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
      inputEl.focus();
    }
  }

  formEl.addEventListener('submit', handleSubmit);

  // ---------- New chat ----------

  newChatBtn.addEventListener('click', () => {
    const session = { id: makeId(), title: 'New chat', messages: [] };
    sessions.unshift(session);
    currentSessionId = session.id;
    localStorage.setItem(CURRENT_KEY, currentSessionId);
    saveSessions(sessions);
    clearError();
    renderHistoryList();
    renderMessages();
    inputEl.focus();
  });

  // ---------- Init ----------

  ensureSession();
  renderHistoryList();
  renderMessages();
})();
